======================
Color output functions
======================

.. automodule:: fabric.colors
    :members:
    :undoc-members:
