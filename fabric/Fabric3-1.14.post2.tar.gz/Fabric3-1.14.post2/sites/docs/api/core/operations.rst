==========
Operations
==========

.. automodule:: fabric.operations
    :members:
