from fabric.api import task

from support.tree.system import debian

@task
def install_package():
    pass
