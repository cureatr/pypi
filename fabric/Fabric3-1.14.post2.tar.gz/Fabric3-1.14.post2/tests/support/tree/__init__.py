from fabric.api import task

from support.tree import system, db


@task
def deploy():
    pass

@task
def build_docs():
    pass
