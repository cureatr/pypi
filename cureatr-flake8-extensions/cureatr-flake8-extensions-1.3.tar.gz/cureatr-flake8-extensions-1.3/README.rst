# cureatr-flake8
cureatr's flake8 extension package.
