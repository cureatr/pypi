import warnings
warnings.simplefilter('error')
